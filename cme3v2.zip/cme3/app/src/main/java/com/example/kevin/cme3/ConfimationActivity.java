package com.example.kevin.cme3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class ConfimationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confimation);

        Intent intent = getIntent();
        String title = intent.getStringExtra(CreateActivity.EXTRA_TEXT_TITLE);
        String date = intent.getStringExtra(CreateActivity.EXTRA_TEXT_DATE);
        String time = intent.getStringExtra(CreateActivity.EXTRA_TEXT_TIME);

        TextView titleText = (TextView) findViewById(R.id.ConfirmTitle);
        TextView dateText = (TextView) findViewById(R.id.ConfirmDate);
        TextView timeText = (TextView) findViewById(R.id.ConfirmTime);

        titleText.setText(title);
        dateText.setText(date);
        timeText.setText(time);
    }
}
