package com.example.kevin.cme3;

import android.Manifest;
import android.content.Intent;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.test.mock.MockPackageManager;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class ProfileActivity extends AppCompatActivity implements View.OnClickListener{

    FirebaseDatabase database;
    DatabaseReference myRef;

    ImageView btnShowlocation;
    ImageView create;
    private static final int REQUEST_CODE_PERMISSION = 2;
    String mPermission = Manifest.permission.ACCESS_FINE_LOCATION;

    GPSTracker gps;
    TextView location;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        try{
            if (ActivityCompat.checkSelfPermission(this,mPermission)!= MockPackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(this, new String[]{mPermission},REQUEST_CODE_PERMISSION);
            }
        }catch (Exception e){
            e.printStackTrace();
        }


        findViewById(R.id.imageViewLive).setOnClickListener(this);
        findViewById(R.id.imageViewCreate).setOnClickListener(this);


        }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.imageViewLive:
                gps = new GPSTracker(ProfileActivity.this);
                location = (TextView) findViewById(R.id.locationText);
                if (gps.canGetLocation()){
                    double latitude = gps.getLatitude();
                    double longitude = gps.getLongitude();
                    database = FirebaseDatabase.getInstance();
                    location.setText(latitude+""+longitude);
                    myRef = database.getReference("Location");
                    myRef.setValue(latitude + "," + longitude);
                }else{
                    gps.showSettingsAlert();
                }
                break;

            case R.id.imageViewCreate:
                startActivity(new Intent(this, CreateActivity.class));
                break;
        }
    }

}


