package com.example.kevin.cme3;

/**
 * Created by Kevin on 21/05/2018.
 */

public class JoinEvent {

    public String eventGuests;

    public JoinEvent(String eventGuests)
    {
        this.eventGuests = eventGuests;
    }



    public JoinEvent()
    {}


}
