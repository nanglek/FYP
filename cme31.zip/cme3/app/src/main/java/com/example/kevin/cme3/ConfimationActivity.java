package com.example.kevin.cme3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Random;

public class ConfimationActivity extends AppCompatActivity {


    TextView textViewTitle;
    TextView textViewDate;
    TextView textViewTime;
    TextView textViewLocation;

    String title, date, time, loc, myLoc, code;
    String userId;
    FirebaseUser user;
    FirebaseAuth auth;


    Button bt;

    FirebaseDatabase database;
    DatabaseReference databaseEvents;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confimation);


        Intent intent = getIntent();
        title = intent.getStringExtra(CreateActivity.EXTRA_TEXT_TITLE);
        date = intent.getStringExtra(CreateActivity.EXTRA_TEXT_DATE);
        time = intent.getStringExtra(CreateActivity.EXTRA_TEXT_TIME);
        loc = intent.getStringExtra(CreateActivity.EXTRA_TEXT_LOC);
        myLoc = intent.getStringExtra(CreateActivity.EXTRA_POS);

        final TextView titleText = (TextView) findViewById(R.id.ConfirmTitle);
        TextView dateText = (TextView) findViewById(R.id.ConfirmDate);
        final TextView timeText = (TextView) findViewById(R.id.ConfirmTime);
        TextView locText = (TextView) findViewById(R.id.ConfirmLocation);

        titleText.setText(title);
        dateText.setText(date);
        timeText.setText(time);
        locText.setText(loc);

        Random r = new Random();
        final int num = r.nextInt(99999 - 1) + 1;

        TextView pinText = (TextView) findViewById(R.id.textViewPin);
        String pin = Integer.toString(num);
        pinText.setText(pin);

        code = pin;

       /* database = FirebaseDatabase.getInstance();
        databaseEvents = database.getReference("events");

        databaseEvents.setValue(title);*/



        addEvent();


       /* final int random = new Random().nextInt(61) + 20;

        TextView randomPin = (TextView) findViewById(R.id.textViewPin);
        randomPin.setText(random);*/

        bt = (Button)findViewById(R.id.buttonShare);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");


                intent.putExtra(Intent.EXTRA_TEXT, "Hi there, plase accept my invitateion to my event:"+ '\n' + '\n'
                        + title + '\n' + date + '\n' + time + '\n' + loc + '\n' + '\n' + "Use the code below to accept the invitation: " +
                        '\n' + '\n' + num);
                startActivity(Intent.createChooser(intent, "Share using"));
            }
        });


    }

    public void addEvent(){

        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();
        userId = user.getUid();


        CreateEvent createEvent = new CreateEvent(title, date, time, loc, myLoc, code, userId);



        databaseEvents = FirebaseDatabase.getInstance().getReference().child(userId);
        databaseEvents.setValue(createEvent);




       // String id = databaseEvents.push().getKey();

       // databaseEvents.setValue(title);
    }
}
