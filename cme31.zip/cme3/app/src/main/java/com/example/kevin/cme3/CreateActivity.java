package com.example.kevin.cme3;

import android.app.DatePickerDialog;
import android.app.DialogFragment;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

public class CreateActivity extends AppCompatActivity implements DatePickerDialog.OnDateSetListener, TimePickerDialog.OnTimeSetListener{

    public static final String EXTRA_TEXT_TITLE = "EXTRA_TEXT_TITLE";
    public static final String EXTRA_TEXT_DATE = "EXTRA_TEXT_DATE";
    public static final String EXTRA_TEXT_TIME = "EXTRA_TEXT_TIME";
    public static final String EXTRA_TEXT_LOC = "EXTRA_TEXT_LOC";
    public static final String EXTRA_POS = "EXTRA_POS";

    String myLoc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);


        TextView dateText = (TextView) findViewById(R.id.editTextEventDate);
        dateText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                android.support.v4.app.DialogFragment datePicker = new DatePickerFragment();
                datePicker.show(getSupportFragmentManager(),"date picker");
            }
        });
        Button button = (Button) findViewById(R.id.buttonCreateEvent);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openConfirmationActivity();
            }
        });

        TextView timeText = (TextView) findViewById(R.id.editTextEventTime);
        timeText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                android.support.v4.app.DialogFragment timePicker = new TimePickerFragment();
                timePicker.show(getSupportFragmentManager(), "time picker");
            }
        });

        Intent intent = getIntent();
        myLoc = intent.getStringExtra(ProfileActivity.EXTRA_COORDS);

    }

    public void openConfirmationActivity(){

        EditText titleText = (EditText) findViewById(R.id.editTextEventTitle);
        TextView dateText = (TextView) findViewById(R.id.editTextEventDate);
        TextView timeText = (TextView) findViewById(R.id.editTextEventTime);
        TextView locationText = (TextView) findViewById(R.id.editTextEventLocation);

        String title = titleText.getText().toString();
        String date = dateText.getText().toString();
        String time = timeText.getText().toString();
        String loc = locationText.getText().toString();




        Intent intent = new Intent(this, ConfimationActivity.class);
        intent.putExtra(EXTRA_TEXT_TITLE, title);
        intent.putExtra(EXTRA_TEXT_DATE, date);
        intent.putExtra(EXTRA_TEXT_TIME, time);
        intent.putExtra(EXTRA_TEXT_LOC, loc);
        intent.putExtra(EXTRA_POS, myLoc);

        startActivity(intent);
    }


    @Override
    public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.YEAR, year);
        c.set(Calendar.MONTH, month);
        c.set(Calendar.DAY_OF_MONTH, dayOfMonth);
        String currentDateString = DateFormat.getDateInstance().format(c.getTime());

        TextView dateText = (TextView) findViewById(R.id.editTextEventDate);
        dateText.setText(currentDateString);

    }

    @Override
    public void onTimeSet(TimePicker timePicker, int hourOfDay, int minute) {
        TextView timeText = (TextView) findViewById(R.id.editTextEventTime);

        timeText.setText(hourOfDay + " : " + minute);

    }



}
