package com.example.kevin.cme3;

/**
 * Created by Kevin on 26/04/2018.
 */

public class CreateEvent {


    public CreateEvent(String title, String date, String time, String loc, String myLoc, String code, String userId) {
        this.title = title;
        this.date = date;
        this.time = time;
        this.loc = loc;
        this.myLoc = myLoc;
        this.code = code;
        this.userId = userId;
    }

    public String title;
    public String date;
    public String time;
    public String loc;
    public String myLoc;
    public String code;
    public String userId;


}
