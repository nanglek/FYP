package com.example.kevin.cme3;

import android.Manifest;
import android.content.Intent;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.test.mock.MockPackageManager;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class ProfileActivity extends AppCompatActivity implements View.OnClickListener{

    public static final String EXTRA_LAT_LONG = "EXTRA_LONG";
    public static final String EXTRA_COORDS = "EXTRA_COORDS";


    FirebaseDatabase database;
    DatabaseReference myRef;

    ImageView btnShowlocation;
    ImageView create;
    private static final int REQUEST_CODE_PERMISSION = 2;
    String mPermission = Manifest.permission.ACCESS_FINE_LOCATION;

    GPSTracker gps;
    TextView location;

    String value;

    double lati;
    double longi;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        try{
            if (ActivityCompat.checkSelfPermission(this,mPermission)!= MockPackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(this, new String[]{mPermission},REQUEST_CODE_PERMISSION);
            }
        }catch (Exception e){
            e.printStackTrace();
        }

        track();

        Intent intent = new Intent(this, ConfimationActivity.class);
        intent.putExtra(EXTRA_COORDS, value);

        findViewById(R.id.imageViewLive).setOnClickListener(this);
        findViewById(R.id.imageViewCreate).setOnClickListener(this);
        //findViewById(R.id.buttonMyMap).setOnClickListener(this);
        findViewById(R.id.AcceptView2).setOnClickListener(this);
        findViewById(R.id.imageViewUpcoming).setOnClickListener(this);
        }


    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.imageViewLive:
                Intent intent = new Intent(this, MapsActivity2.class);
                startActivity(intent);
                break;




             /*   gps = new GPSTracker(ProfileActivity.this);
                location = (TextView) findViewById(R.id.locationText);
                if (gps.canGetLocation()){
                    double latitude = gps.getLatitude();
                    double longitude = gps.getLongitude();

                    database = FirebaseDatabase.getInstance();
                    location.setText(latitude+","+longitude);
                    myRef = database.getReference("Location");
                    myRef.setValue(latitude + "," + longitude);

                    value = location.getText().toString();

                }else{
                    gps.showSettingsAlert();
                }


                break;*/

            case R.id.imageViewCreate:
                intent = new Intent(this, CreateActivity.class);
                intent.putExtra(EXTRA_COORDS, value);
                startActivity(intent);

                break;

            /*case R.id.buttonMyMap:
                intent = new Intent(ProfileActivity.this, MapsActivity2.class);
                intent.putExtra("LOCVAL", value);
                startActivity(intent);

                break;*/

            case R.id.AcceptView2:
                intent = new Intent(this, AcceptActivity.class);
                intent.putExtra(EXTRA_COORDS, value);
                startActivity(intent);

                break;

            case R.id.imageViewUpcoming:
                intent = new Intent(this, UpcomingActivity.class);
                startActivity(intent);

                break;
        }
    }

    public void buttonCicked (View view){
        Intent intent = new Intent(ProfileActivity.this, MapsActivity2.class);
        intent.putExtra("LOCVAL", value);
        startActivity(intent);

    }

    public void track (){

        gps = new GPSTracker(ProfileActivity.this);
        location = (TextView) findViewById(R.id.locationText);
        if (gps.canGetLocation()){
            double latitude = gps.getLatitude();
            double longitude = gps.getLongitude();

            database = FirebaseDatabase.getInstance();
            location.setText(latitude+","+longitude);
            myRef = database.getReference().child("Events");
            myRef.setValue(latitude + "," + longitude);

            //value = location.getText().toString();

            lati = latitude;
            longi = longitude;




            //Intent intent = new Intent(this, ConfimationActivity.class);
            //intent.putExtra(EXTRA_COORDS, value);

        }else{
            gps.showSettingsAlert();
        }
    }

}


